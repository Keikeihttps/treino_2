const express = require('express');
const { Pool } = require('pg');

const app = express();
const port = 3000;

app.use(express.json());

const pool = new Pool({

    host: 'localhost',
    port: 5432,
    user: postgres,
    password: aluno,
    database: plural
});


app.post('login/', async (request, response) => {
    const { usuario, senha } = request.body;

    const resultado = await pool.query(
        'select id, nome from usuario where nome = $1 and senha = $2',
        [usuario, senha]
    )
});

