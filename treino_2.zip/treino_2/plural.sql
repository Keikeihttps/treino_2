create database plural;

create table usuario( 
id serial primary key,
nome varchar(255) not null,
senha varchar(20) not null

);

create table responsavel(
id serial primary key,
nome varchar(255) not null

);

create table aluno(
id serial primary key,
nome varchar(255) not null,
responsavel_id int not null references responsavel(id)

);

create table atendimento(
id serial primary key,
data date not null,
aluno_id int not null references aluno(id),
usuario_id int not null references usuario(id)

);

insert into usuario 
values 
(1, 'kei', '1234'),
(2, 'bubu', '2345'),
(3, 'misty', '3456');

insert into responsavel 
values
(1, 'mimity'),
(2, 'mity'),
(3, 'mitynha');

insert into aluno 
values
(1, 'miiiii', 1),
(2, 'tyyyyy', 2),
(3, 'mimiiii', 3);

insert into atendimento 
values
(1, '2026-10-5', 1, 1),
(2, '2026-10-6', 2, 2),
(3, '2026-10-7', 3, 3);