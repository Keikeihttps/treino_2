const express = require('express');
const { Pool } = require('pg');
const bcrypt = require('bcrypt');

const app = express();
const port = 3000;

app.use(express.json());

const pool = new Pool({

    host: 'localhost',
    port: 5432,
    user: 'postgres',
    password: 'aluno',
    database: 'plural'
});

app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`)
})

app.post('/cadastro', async (request, response) => {
    const { nome, senha } = request.body;

    const hash = await bcrypt.hash(senha, 10)

    const resultado = await pool.query(
        `insert into usuario (nome, senha)
        values ($1, $2)
        returning *`,
        [nome, hash]
    )

    response.json(resultado.rows[0]);
});


app.post('/login', async (request, response) => {
    const { usuario, senha } = request.body;

    const hash = await bcrypt.hash(senha, 10)

    const resultado = await pool.query(
        `select * from usuario where nome = $1 and senha = $2`,
        [usuario, hash]
    );

    console.log(usuario);
    console.log(hash);

    if (resultado.rows.length === 0){

        return response.status(401).json({
            erro: "Usuário ou senha incorretos"
        })

    }else{

        return response.json({

            mensagem:"Login efetuado"

        })

    }

});

app.post('/aluno', async (request, response) => {
    const { nome, responsavel_id } = request.body;

    const resultado = await pool.query(
        `insert into aluno(nome, responsavel_id)
        values ($1, $2)
        returning *`, 
        [ nome, responsavel_id]
    );

    response.status(201).json(resultado.rows[0]);

});

app.post('/responsavel', async (request, response) => {
    const { nome } = request.body;

    const resultado = await pool.query(
    `insert into responsavel(nome)
    values ($1)
    returning *`,
    [ nome ]
    );

    response.status(201).json(resultado.rows[0]);

});

app.post('/atendimento', async (request, response) => {
    const { data, aluno_id, usuario_id } = request.body;

    const resultado = await pool.query(
        `insert into atendimento(data, aluno_id, usuario_id)
        values ($1, $2, $3)
        returning *`,
        [ data, aluno_id, usuario_id]
    );

    response.status(201).json(resultado.rows[0]);

});

app.get('/login', async (request, response) => {
    const resultado = await pool.query(
        `select * from usuario`
    );

    response.status(201).json(resultado.rows);
});

app.get('/aluno', async (request, response) => {
    const resultado = await pool.query(
        `select * from aluno`
    );

    response.status(201).json(resultado.rows);
});

app.get('/responsavel', async (request, response) => {
    const resultado = await pool.query(
        `select * from responsavel`
    );

    response.status(201).json(resultado.rows);
});

app.get('/atendimento', async (request, response) => {
    const resultado = await pool.query(
        `select * from atendimento`
    );

    response.status(201).json(resultado.rows);
});

